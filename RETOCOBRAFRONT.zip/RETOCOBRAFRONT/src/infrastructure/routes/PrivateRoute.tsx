/* eslint-disable @typescript-eslint/no-explicit-any */
import React from 'react';
import { Navigate } from 'react-router-dom';

interface PrivateRouteProps {
    isAuthenticated: boolean;
    authenticationPath: string;
    component: React.ComponentType<any>;
  }
  

  const PrivateRoute: React.FC<PrivateRouteProps> = ({
    isAuthenticated,
    authenticationPath,
    component: Component,
  }) => {
  return isAuthenticated ? (
   <Component />
  ) : (
    <Navigate to={authenticationPath} replace />
  );
};

export default PrivateRoute;