import React, { useEffect, useState } from 'react';
import Table from '../components/molecule/Table';
import { Link } from 'react-router-dom';
import CreateModal from '../components/Root/CreateModal';
import getCards from '../../aplication/useCases/cardsUseCase';

import Button from '../components/atom/Button';

interface Cards {
  id?: string;
  dni: string;
  name?: string;
  lastName?: string;
  email?: string;
  phone?: string;
  numberCard?: string;
  typeCard?: string;
  
}

const HomePage: React.FC = () => {
    const [modalOpen, setModalOpen] = useState(false);
    const [cards, setCards] = useState<Cards[]>([]);

    const openModal = () => {
      setModalOpen(true);
    };
  
    const closeModal = () => {
      setModalOpen(false);
    };

    useEffect(() => {
      const fetchData = async () => {
        try {
          const fetchedCards = await getCards();
          setCards(fetchedCards);
        } catch (error) {
          console.error('Error fetching users:', error);
        }
      };
  
      fetchData()
      console.log(cards)
    }, [])
    

  const columns = [
    { key: '_id', label: 'ID' },
    { key: 'name', label: 'Nombre' },
    { key: 'lastName', label: 'Apellido' },
    { key: 'email', label: 'Email' },
    { key: 'phone', label: 'Teléfono' },   
    { key: 'numberCard', label: 'Número de Tarjeta' },
    { key: 'typeCard', label: 'Tipo de Tarjeta' },
  ];

  const data = cards

  return (
    <>
        <div className="container mx-auto mt-8 flex flex-col lg:flex-row">
        <div className="w-full lg:w-1/4 bg-gray-200 p-4 mb-4 lg:mb-0 rounded-md lg:mr-4">
            <h3 className="text-xl font-semibold mb-4">CRUD RETO COBRA</h3>
            <ul>
            <li className="mb-2">
                <Button onClick={() => openModal()} type='button'>Crear Tarjetahabiente</Button>
            </li>
            <li>
                <Link to="/logout" className="text-red-500 hover:text-red-700">Cerrar sesión</Link>
            </li>
            </ul>
        </div>
        <div className="w-[80%] lg:flex-1">
            <h2 className="text-2xl font-semibold mb-4">Lista de tarjetahabientes</h2>
            <Table columns={columns} data={data} />
        </div>
        </div>
        <CreateModal isOpen={modalOpen} closeModal={closeModal}/>
    </>

  );
};

export default HomePage;