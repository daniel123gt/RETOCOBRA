import React from 'react';
import LoginForm from '../components/Root/LoginForm';

const Login: React.FC = () => {
  const handleLogin = (username: string, password: string) => {
    console.log('Iniciar sesión con:', username, password);
  };

  return (
    <div className="min-h-screen bg-gray-100 flex justify-center items-center">
    <div className="bg-white p-8 shadow-md rounded-md max-w-md w-full">
      <h2 className="text-2xl font-semibold text-gray-800 mb-6">Iniciar sesión</h2>
      <LoginForm onLogin={handleLogin} />
    </div>
  </div>
  );
};

export default Login;