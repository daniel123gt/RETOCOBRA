import React from 'react';
import Button from '../atom/Button';

interface TableColumn {
  key: string;
  label: string;
}

interface TableRow {
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  [key: string]: any;
}

interface TableProps {
  columns: TableColumn[];
  data: TableRow[];
}

const Table: React.FC<TableProps> = ({ columns, data }) => {
  return (
    <div className="overflow-x-auto">
    <table className="table-auto overflow-scroll w-[40%] border-collapse border border-gray-200">
      <thead>
      <tr className="bg-gray-50">
          {columns.map(column => (
            <th className="px-4 py-2 text-sm font-semibold text-gray-500 border-b" key={column.key}>{column.label}</th>
          ))}
          <th className="px-4 py-2 text-sm font-semibold text-gray-500 border-b" >Actions</th>
        </tr>
      </thead>
      <tbody>
      {data.map((row, index) => (
          <tr className="bg-white" key={index}>
            {columns.map(column => (
              <td className="px-4 py-2 text-sm font-normal text-gray-500 border-b" >{row[column.key]}</td>
            ))}
            <td className="px-4 py-2 text-sm font-normal text-gray-500 border-b flex justify-between gap-2" key={'actions'}>
                <Button type='button' onClick={() => console.log('editar')}>Editar</Button>
                <Button variant='danger' type='button' onClick={() => console.log('eliminar')}>Eliminar</Button>
            </td>
          </tr>
        ))}
      </tbody>
    </table>
  </div>
  );
};

export default Table;