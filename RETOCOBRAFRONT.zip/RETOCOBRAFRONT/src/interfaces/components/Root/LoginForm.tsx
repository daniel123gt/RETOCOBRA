import React, { useState, ChangeEvent, FormEvent } from 'react';
import Input from '../atom/Input';
import Button from '../atom/Button';

interface LoginFormProps {
  onLogin: (username: string, password: string) => void;
}

const LoginForm: React.FC<LoginFormProps> = ({ onLogin }) => {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');

  const handleUsernameChange = (event: ChangeEvent<HTMLInputElement>) => {
    setUsername(event.target.value);
  };

  const handlePasswordChange = (event: ChangeEvent<HTMLInputElement>) => {
    setPassword(event.target.value);
  };

  const handleSubmit = (event: FormEvent) => {
    event.preventDefault();
    onLogin(username, password);
  };

  return (
    <form onSubmit={handleSubmit} className="max-w-md mx-auto mt-8">
    <div className="mb-4">
      <Input
        type="text"
        value={username}
        onChange={handleUsernameChange}
        placeholder="Nombre de usuario"
      />
    </div>
    <div className="mb-6">
      <Input
        type="password"
        value={password}
        onChange={handlePasswordChange}
        placeholder="Contraseña"
      />
    </div>
    <Button onClick={() => console.log('Hola')} type="submit">
      Iniciar sesión
    </Button>
  </form>
  );
};

export default LoginForm;