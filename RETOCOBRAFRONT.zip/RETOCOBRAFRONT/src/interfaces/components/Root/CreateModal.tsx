import React from 'react';
import ReactDOM from 'react-dom';

interface ModalProps {
    isOpen: boolean;
    closeModal: () => void;
  }

  const CreateModal: React.FC<ModalProps> = ({ isOpen, closeModal }) => {
    if (!isOpen) return null;
    return ReactDOM.createPortal (
    <>
      {isOpen && (
        <div className="fixed z-10 inset-0 overflow-y-auto">
          <div className="flex items-center justify-center min-h-screen px-4">
            <div className="fixed inset-0 transition-opacity" aria-hidden="true">
              <div className="absolute inset-0 bg-gray-500 opacity-75"></div>
            </div>
            
            <div className="bg-white rounded-lg overflow shadow-xl transform transition-all sm:max-w-lg sm:w-full">
           
              <div className="bg-gray-50 px-4 py-5 sm:px-6">
              <div className="absolute right-0 left-0 -top-56 max-w-md mx-auto bg-gradient-to-tr from-cyan-200 to to-cyan-500 rounded-xl overflow-hidden shadow-md md:max-w-2xl">
                <div className="md:flex">
                    <div className="md:flex-shrink-0">
                    <img className="h-48 w-full object-cover md:w-48" src="https://via.placeholder.com/150" alt="Tarjeta de crédito" />
                    </div>
                    <div className="p-8">
                    <div className="uppercase tracking-wide text-sm text-indigo-500 font-semibold">Número de tarjeta</div>
                    <div className="mt-1 text-gray-900">**** **** **** 1234</div>
                    <div className="uppercase tracking-wide text-sm text-indigo-500 font-semibold mt-4">Nombre del titular</div>
                    <div className="mt-1 text-gray-900">John Doe</div>
                    <div className="md:flex justify-between mt-4">
                        <div>
                        <div className="uppercase tracking-wide text-sm text-indigo-500 font-semibold">Fecha de vencimiento</div>
                        <div className="mt-1 text-gray-900">12/24</div>
                        </div>
                        <div>
                        <div className="uppercase tracking-wide text-sm text-indigo-500 font-semibold">CVC</div>
                        <div className="mt-1 text-gray-900">***</div>
                        </div>
                    </div>
                    </div>
                </div>
                </div>
                <h3 className="text-lg font-medium leading-6 text-gray-900">Crear Nuevo Tarjetahabiente</h3>
              </div>
              <div className="px-4 py-5 sm:p-6">
              <div className="mb-4">
                  <label htmlFor="cardNumber" className="block text-sm font-medium text-gray-700">
                    Número de tarjeta
                  </label>
                  <input
                    type="tel"
                    name="cardNumber"
                    id="cardNumber"
                    className="mt-1 p-2 block w-full border border-gray-300 rounded-md"
                    placeholder="Número de tarjeta"
                  />
                </div>
                <div className="mb-4 inline-block">
                  <label htmlFor="name" className="block text-sm font-medium text-gray-700">
                    Nombre
                  </label>
                  <input
                    type="text"
                    name="name"
                    id="name"
                    className="mt-1 p-2 w-full border border-gray-300 rounded-md"
                    placeholder="Nombres"
                  />
                </div>
                <div className="mb-4 ml-8 inline-block">
                  <label htmlFor="lastname" className="block text-sm font-medium text-gray-700">
                    Apellidos
                  </label>
                  <input
                    type="text"
                    name="lastname"
                    id="lastname"
                    className="mt-1 p-2 w-full border border-gray-300 rounded-md"
                    placeholder="Apellido"
                  />
                </div>
                <div className="mb-4 inline-block">
                  <label htmlFor="email" className="block text-sm font-medium text-gray-700">
                    Email
                  </label>
                  <input
                    type="email"
                    name="email"
                    id="email"
                    className="mt-1 p-2 block w-full border border-gray-300 rounded-md"
                    placeholder="Correo electrónico"
                  />
                </div>
                <div className="mb-4 inline-block ml-8">
                  <label htmlFor="phone" className="block text-sm font-medium text-gray-700">
                    Teléfono
                  </label>
                  <input
                    type="tel"
                    name="phone"
                    id="phone"
                    className="mt-1 p-2 block w-full border border-gray-300 rounded-md"
                    placeholder="Número de teléfono"
                  />
                </div>
                
                <div className="mt-4">
                  <button
                    onClick={closeModal}
                    className="inline-flex justify-center w-full px-4 py-2 text-sm font-medium text-white bg-blue-500 border border-transparent rounded-md shadow-sm hover:bg-blue-600 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
                  >
                    Create
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </>,
    document.getElementById('modal-root')!
  );
};

export default CreateModal;
