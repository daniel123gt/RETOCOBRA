import React, { MouseEventHandler } from 'react';

interface ButtonProps {
  onClick: MouseEventHandler<HTMLButtonElement>;
  disabled?: boolean;
  type?: 'button' | 'submit' | 'reset';
  children: React.ReactNode;
  variant?: 'primary' | 'danger'
}

const Button: React.FC<ButtonProps> = ({ onClick, disabled, children, type, variant = 'primary' }) => {
  return (
    <button onClick={onClick} disabled={disabled} type={type} className={`${variant == 'primary' && 'bg-blue-500' || 'bg-red-600'}  text-white font-semibold py-2 px-4 rounded-md`}>
      {children}
    </button>
  );
};

export default Button;