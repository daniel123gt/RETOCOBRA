import React from 'react';
import { Routes, Route } from 'react-router-dom';
import Login from './interfaces/pages/Login';
import Home from './interfaces/pages/Home'
import { PrivateRoute } from './infrastructure/routes';

const App: React.FC = () => {
  return (
    <>
      <Routes>
        <Route path="/" element={<Login/>} />
        <Route path="/home" element={<PrivateRoute component={Home} isAuthenticated={true} authenticationPath="/" />} />
      </Routes>
    </>
  );
};

export default App;