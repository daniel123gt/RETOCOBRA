import fetchCards from "../../adapters/http/cardsListService";

const getCards = async (): Promise<Cards[]> => {
  try {
    const cards = await fetchCards();
    return cards;
  } catch (error) {
    console.error('Error getting users:', error);
    throw error;
  }
};

export default getCards;

interface Cards {
    id?: string;
    dni: string;
    name?: string;
    lastName?: string;
    email?: string;
    phone?: string;
    numberCard?: string;
    typeCard?: string;
}