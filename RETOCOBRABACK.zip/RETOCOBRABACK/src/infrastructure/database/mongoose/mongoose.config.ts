import mongoose, { ConnectOptions } from 'mongoose';

mongoose.set('debug', true);
export const connectToDatabase = async (): Promise<void> => {
    const mongoURI = process.env.MONGODB_URI || 'mongodb+srv://cdanielgtovar:1lfvyboAud0nVdtk@cluster0.fuapvzq.mongodb.net/CardHolder?retryWrites=true&w=majority';


    try {
        await mongoose.connect(mongoURI);
        console.log('Conectado a MongoDB Atlas');
    } catch (error) {
        console.error('Error al conectarse a MongoDB Atlas:', error);
        process.exit(1);
    }
};

export const closeDatabaseConnection = async (): Promise<void> => {
    try {
        await mongoose.connection.close();
        console.log('Disconnected from MongoDB');
    } catch (error) {
        console.error('Error closing MongoDB connection:', error);
    }
}
