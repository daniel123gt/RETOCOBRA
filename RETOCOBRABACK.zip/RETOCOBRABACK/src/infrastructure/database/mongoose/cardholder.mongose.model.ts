import { model, Schema, Document } from 'mongoose';
import { CardHolder } from '../../../domain/cardholder/models/cardholder.model';


const cardHolderSchema = new Schema<CardHolder & Document>({

    dni: { type: String, required: true, },
    name: { type: String, required: true, },
    lastName: { type: String, required: true, },
    email: { type: String, required: true, },
    phone: { type: String, required: true },
    numberCard: { type: String, required: true, unique: true },
    typeCard: { type: String, required: true, },
}, { collection: 'CardHolder' });


export const CardHolderModel = model<CardHolder & Document>('CardHolder', cardHolderSchema);
