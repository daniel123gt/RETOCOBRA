
import express, { Application } from 'express';
import { CardHolderController } from './cardholder.controller';

export const configureCardHolderRoutes = (app: Application): void => {
    const router = express.Router();


    router.post('/cardHolders', CardHolderController.createCardHolder);
    router.get('/cardHolders/:id', CardHolderController.getCardHolderById);
    router.get('/cardHolders', CardHolderController.getAllCardHolders);
    router.delete('/cardHolders/:dni', CardHolderController.deleteByDni);
    router.get('/cardHolders/:id/decrypted', CardHolderController.getDecryptedCardHolderById);
    app.use('/api', router);
};
