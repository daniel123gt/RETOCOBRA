import { Request, Response } from 'express';
import { CardHolderService } from '../../application/cardholder/cardholder.service';
import { CardHolderRepository } from '../../domain/cardholder/repositories/cardholder.repository';
import { DecryptionService } from '../../application/cardholder/decryption.service';
import { CardHolder } from '../../domain/cardholder/models/cardholder.model';

export class CardHolderController {

    private readonly cardHolderService: CardHolderService;

    constructor() {
        this.cardHolderService = new CardHolderService(new CardHolderRepository(), process.env.KEY_ENCRY || '');
    }
    static async createCardHolder(req: Request, res: Response): Promise<void> {
        try {
            const cardHolderRepository = new CardHolderRepository();
            const cardHolderService = new CardHolderService(cardHolderRepository, process.env.KEY_ENCRY || '');
            const cardHolder = await cardHolderService.createCardHolder(req.body);
            res.status(201).json(cardHolder);
        } catch (error) {
            console.error('Error al crear cardHolder:', error);
            res.status(500).send('Error interno del servidor');
        }
    }

    static async getCardHolderById(req: Request, res: Response): Promise<void> {
        try {
            const cardHolderRepository = new CardHolderRepository();
            const cardHolderService = new CardHolderService(cardHolderRepository, process.env.KEY_ENCRY || '');


            const cardHolderId = req.params.id;

            const cardHolder = await cardHolderService.getCardHolderById(cardHolderId);

            if (cardHolder) {
                res.json(cardHolder);
            } else {
                res.status(404).send('CardHolder no encontrado');
            }
        } catch (error) {
            console.error('Error al obtener cardHolder por ID:', error);
            res.status(500).send('Error interno del servidor');
        }
    }

    static async getAllCardHolders(req: Request, res: Response): Promise<void> {
        try {
            const cardHolderRepository = new CardHolderRepository();
            const cardHolderService = new CardHolderService(cardHolderRepository, process.env.KEY_ENCRY || '');

            const cardHolders = await cardHolderService.getAllCardHolders();
            res.json(cardHolders);
        } catch (error) {
            console.error('Error al obtener todos los cardHolders:', error);
            res.status(500).send('Error interno del servidor');
        }
    }
    static async deleteByDni(req: Request, res: Response): Promise<void> {
        const { dni } = req.params;

        try {
            const cardHolderRepository = new CardHolderRepository();
            const cardHolderService = new CardHolderService(cardHolderRepository, process.env.KEY_ENCRY || '');


            await cardHolderService.deleteByDni(dni);
            res.status(204).send();
        } catch (error) {
            console.error(`Error al eliminar por DNI ${dni}:`, error);
            res.status(500).send('Error interno del servidor');
        }
    }

    static async getDecryptedCardHolderById(id: string): Promise<CardHolder | null> {
        try {


            const cardHolderRepository = new CardHolderRepository();
            const cardHolderService = new CardHolderService(cardHolderRepository, process.env.KEY_ENCRY || '');
            const cardHolder = await cardHolderRepository.findById(id);
            console.log(cardHolder, '---')
            /* if (cardHolder) {
                 const decryptedCardHolder = await DecryptionService.decryptCardHolderFields(cardHolder) as CardHolder;
                 return decryptedCardHolder;
             }*/

            return null;
        } catch (error) {
            console.error('Error al obtener y desencriptar cardHolder por ID:', error);
            return null;
        }
    }





}
