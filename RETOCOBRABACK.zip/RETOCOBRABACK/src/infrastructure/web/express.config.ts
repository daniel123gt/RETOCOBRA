// src/interfaces/web/express/express.config.ts
import express, { Application } from 'express';
import bodyParser from 'body-parser';
import { configureCardHolderRoutes } from './cardholder.routes';

export const configureExpress = (app: Application): void => {
    app.use(bodyParser.json());
    configureCardHolderRoutes(app);

};
