import express, { Application } from 'express';

import bodyParser from 'body-parser';
import morgan from 'morgan';
import cors from 'cors';
import helmet from 'helmet';

class ConfigureExpress {
    public app: Application;

    constructor() {
        this.app = express();
        this.configureMiddleware();
    }

    private configureMiddleware(): void {

        this.app.use(morgan('dev'));
        this.app.use(bodyParser.json());
        this.app.use(bodyParser.urlencoded({ extended: true }));
        this.app.use(helmet());
        this.app.use(cors());


    }
    async initialize(): Promise<void> {

    }
}

export const configureExpress = new ConfigureExpress();
