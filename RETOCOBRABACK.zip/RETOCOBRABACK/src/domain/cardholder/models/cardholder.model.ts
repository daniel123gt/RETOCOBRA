import { Document } from 'mongoose';

export interface CardHolder extends Document {
    _id?: string;
    dni: string;
    name?: string;
    lastName?: string;
    email?: string;
    phone?: string;
    numberCard?: string;
    typeCard?: string;

}