import { model, Schema, Document } from 'mongoose';
import { CardHolder } from '../models/cardholder.model';
import { CardHolderModel } from '../../../infrastructure/database/mongoose/cardholder.mongose.model';

export class CardHolderRepository {


    async create(cardholder: CardHolder): Promise<CardHolder> {
        const createdCardholder = await CardHolderModel.create(cardholder);
        return createdCardholder.toObject();
    }

    async findById(id: string): Promise<CardHolder | null> {
        console.log(id, '---****--')
        const cardholder = await CardHolderModel.findById(id);
        if (!cardholder) {
            console.error('ID no encontrado:', id);
        }
        return cardholder as CardHolder | null;
    }

    async findAll(): Promise<CardHolder[]> {
        try {

            const cardholders = await CardHolderModel.find();
            return cardholders as CardHolder[];
        } catch (error) {

            throw error;
        }
    }

    async deleteByDni(dni: string): Promise<void> {
        await CardHolderModel.deleteOne({ dni });
    }

    async findByNumberCard(numberCard: string): Promise<any | null> {
        try {

            const cardholder = await CardHolderModel.findOne({ numberCard }).lean();
            return cardholder;
        } catch (error) {
            console.error('Error al buscar por número de tarjeta:', error);
            throw error;
        }
    }

    async getByDecryptedNumberCard(decryptedNumberCard: string): Promise<CardHolder> {

        console.log(decryptedNumberCard, 'decryptedNumberCard-------------------------')
        const cardholder = await CardHolderModel.findOne({ decryptedNumberCard });

        console.log(cardholder, 'getByDecryptedNumberCard')
        return cardholder as CardHolder;
    }



}