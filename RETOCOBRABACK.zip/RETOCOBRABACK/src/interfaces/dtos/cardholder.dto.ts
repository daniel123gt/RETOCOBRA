export interface CardHolderDTO {
    name?: string;
    lastName?: string;
    email?: string;
    phone?: string;
    numberCard?: string;
    typeCard?: string;
}

export function mapToCardHolderDTO(cardHolder: CardHolderDTO): CardHolderDTO {
    return {
        name: cardHolder.name,
        lastName: cardHolder.lastName,
        email: cardHolder.email,
        phone: cardHolder.phone,
        numberCard: cardHolder.numberCard,
        typeCard: cardHolder.typeCard,
    };
}
