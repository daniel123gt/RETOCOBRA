
import { CardHolderRepository } from '../../domain/cardholder/repositories/cardholder.repository';
import { CardHolderDTO } from '../../interfaces/dtos/cardholder.dto';
import { CardHolder } from '../../domain/cardholder/models/cardholder.model';

import { EncryptionService } from '../../infrastructure/encryption/encryption.service';
import { DecryptionService } from './decryption.service';

export class CardHolderService {
    private readonly cardHolderRepository: CardHolderRepository;
    private readonly encryptionKey: string;

    constructor(cardHolderRepository: CardHolderRepository, encryptionKey: string) {
        this.cardHolderRepository = cardHolderRepository;
        this.encryptionKey = encryptionKey;
    }

    async createCardHolder(cardHolder: CardHolder): Promise<CardHolder> {

        if (cardHolder.numberCard) {
            const { numberCard, ...otherData } = cardHolder;


            const encryptNumberCard = await EncryptionService.encrypt(numberCard, this.encryptionKey);
            const decryptedNumberCard = await this.cardHolderRepository.getByDecryptedNumberCard(encryptNumberCard);
            //console.log(decryptedNumberCard, 'decryptedNumberCard.numberCard ', decryptedNumberCard.numberCard)
            if (decryptedNumberCard) {
                const numberCard = decryptedNumberCard.numberCard || '';
                const existingCardHolder = await this.cardHolderRepository.findByNumberCard(numberCard);

                if (existingCardHolder) {
                    throw new Error('¡El número de tarjeta ya está registrado!');
                }

            }
            else {
                const encryptedNumberCard = await EncryptionService.encrypt(cardHolder.numberCard, this.encryptionKey);
                console.log(encryptedNumberCard, 'encripta')
                if (cardHolder.email && cardHolder.phone) {
                    const encryptedEmail = await EncryptionService.encrypt(cardHolder.email, this.encryptionKey);
                    const encryptedPhone = await EncryptionService.encrypt(cardHolder.phone, this.encryptionKey);
                    cardHolder.email = encryptedEmail;
                    cardHolder.phone = encryptedPhone;
                }
                cardHolder.numberCard = encryptedNumberCard;


            }
        } else {
            throw new Error('El número de tarjeta no pudo ser desencriptado');
        }

        return this.cardHolderRepository.create(cardHolder);

    }
    async getCardHolderById(id: string): Promise<CardHolder | null> {
        try {
            return this.cardHolderRepository.findById(id);
        } catch (error) {
            console.error('Error al buscar cardHolder por ID:', error);
            throw error;
        }
    }

    async getAllCardHolders(): Promise<CardHolder[]> {
        try {
            console.log('getAllCardHolders service')
            if (!this.cardHolderRepository) {
                throw new Error('CardHolderRepository no está inicializado en CardHolderService');
            }

            const cardHolders = await this.cardHolderRepository.findAll();

            return cardHolders;
        } catch (error) {
            console.error('Error al obtener todos los cardHolders:', error);
            throw error;
        }
    }

    async getTypeCard(number: string) {

    }
    async deleteByDni(dni: string): Promise<void> {

        await this.cardHolderRepository.deleteByDni(dni);
    }

    async getByDecryptedNumberCard(data: string): Promise<CardHolder | null> {

        const decryptedNumberCard = await EncryptionService.decrypt(data, this.encryptionKey);

        return this.cardHolderRepository.getByDecryptedNumberCard(decryptedNumberCard);



    }

    async getDecryptedCardHolderById(id: string): Promise<CardHolder | null> {
        const cardHolder = await this.cardHolderRepository.findById(id);

        if (cardHolder) {
            const decryptedCardHolder = await DecryptionService.decryptCardHolderFields(cardHolder) as CardHolder;
            return decryptedCardHolder;
        }

        return null;
    }





}
