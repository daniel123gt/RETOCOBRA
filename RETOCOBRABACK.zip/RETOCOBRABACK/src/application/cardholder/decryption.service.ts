import { EncryptionService } from "../../infrastructure/encryption/encryption.service";
import { CardHolder } from "../../domain/cardholder/models/cardholder.model";

export class DecryptionService {
    static async decryptCardHolderFields(cardHolder: CardHolder): Promise<Partial<CardHolder>> {
        const { email, phone, ...rest } = cardHolder;

        const decryptedCardHolder: Partial<CardHolder> = {
            ...rest,
            email: email ? await EncryptionService.decrypt(email, process.env.KEY_ENCRY || '') : undefined,
            phone: phone ? await EncryptionService.decrypt(phone, process.env.KEY_ENCRY || '') : undefined,
        };
        console.log(decryptedCardHolder, '*-*-*-*-')

        return decryptedCardHolder;
    }
}
