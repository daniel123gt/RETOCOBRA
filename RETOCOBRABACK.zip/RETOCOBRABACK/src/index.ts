

import express from 'express';
import dotenv from 'dotenv';
import { connectToDatabase } from './infrastructure/database/mongoose/mongoose.config';
import { configureExpress } from '../src/config/configureExpress';
import { configureCardHolderRoutes } from './infrastructure/web/cardholder.routes';

dotenv.config();



(async () => {
    const app = configureExpress.app;
    await configureExpress.initialize();
    await connectToDatabase();

    configureCardHolderRoutes(configureExpress.app);

    const port = process.env.PORT || 3000;
    app.listen(port, () => {
        console.log(`Server active on port :${port}`);
    });
})();
